package eu.agilejava.dukes;


import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("")
public class CompleteDukeApplication extends Application {
}
